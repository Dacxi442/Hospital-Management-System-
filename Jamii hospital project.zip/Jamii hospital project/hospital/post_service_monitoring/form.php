
<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "norah#@$&";
$database = "Jamii1_hospital";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Post-Service Monitoring</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f2f2f2;
        }
        form {
            max-width: 600px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        input[type="date"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h2>Add Post-Service Monitoring</h2>
    <form method="post" action="insertData.php">
        <label for="patient_id">Patient:</label>
        <select id="patient_id" name="patient_id" required>
            <?php
            $sql = "SELECT patient_id, patient_name FROM Patients";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['patient_id'] . "'>" . $row['patient_name'] . "</option>";
                }
            } else {
                echo "<option value=''>No patients available</option>";
            }
            ?>
        </select><br>

        <label for="consultation_id">Consultation:</label>
        <select id="consultation_id" name="consultation_id" required>
            <?php
            $sql = "SELECT consultation_id FROM Consultations";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['consultation_id'] . "'>" . $row['consultation_id'] . "</option>";
                }
            } else {
                echo "<option value=''>No consultations available</option>";
            }
            ?>
        </select><br>

        <label for="monitoring_start_date">Monitoring Start Date:</label>
        <input type="date" id="monitoring_start_date" name="monitoring_start_date" required><br>

        <label for="monitoring_end_date">Monitoring End Date:</label>
        <input type="date" id="monitoring_end_date" name="monitoring_end_date" required><br>

        <label for="notes">Notes:</label>
        <textarea id="notes" name="notes"></textarea><br>

        <input type="submit" name="submit" value="Add Monitoring">
    </form>
</body>
</html>
