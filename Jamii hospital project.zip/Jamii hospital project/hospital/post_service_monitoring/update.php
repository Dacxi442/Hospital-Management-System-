
<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "norah#@$&";
$database = "Jamii1_hospital";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Post-Service Monitoring</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 8px;
            font-weight: bold;
        }
        select,
        input[type="date"],
        textarea {
            width: 100%;
            padding: 10px;
            margin: 5px 0 15px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin-top: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: auto;
            align-self: flex-end;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Update Post-Service Monitoring</h2>
        <?php
        if (isset($_GET['monitoring_id'])) {
            $id = $_GET['monitoring_id'];
            $sql = "SELECT * FROM Post_Service_Monitoring WHERE monitoring_id = $id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
        ?>
                <form method="post" action="update_process.php">
                    <input type="hidden" name="monitoring_id" value="<?php echo $row['monitoring_id']; ?>">
                    <label for="patient_id">Patient:</label>
                    <select id="patient_id" name="patient_id" required>
                        <?php
                        $sql = "SELECT patient_id, patient_name FROM Patients";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row_patient = $result->fetch_assoc()) {
                                $selected = ($row_patient['patient_id'] == $row['patient_id']) ? 'selected' : '';
                                echo "<option value='" . $row_patient['patient_id'] . "' $selected>" . $row_patient['patient_name'] . "</option>";
                            }
                        } else {
                            echo "<option value=''>No patients available</option>";
                        }
                        ?>
                    </select>
                    <label for="consultation_id">Consultation:</label>
                    <select id="consultation_id" name="consultation_id" required>
                        <?php
                        $sql = "SELECT consultation_id FROM Consultations";
                        $result = $conn->query($sql);
                        if ($result->num_rows > 0) {
                            while ($row_consultation = $result->fetch_assoc()) {
                                $selected = ($row_consultation['consultation_id'] == $row['consultation_id']) ? 'selected' : '';
                                echo "<option value='" . $row_consultation['consultation_id'] . "' $selected>" . $row_consultation['consultation_id'] . "</option>";
                            }
                        } else {
                            echo "<option value=''>No consultations available</option>";
                        }
                        ?>
                    </select>
                    <label for="monitoring_start_date">Monitoring Start Date:</label>
                    <input type="date" id="monitoring_start_date" name="monitoring_start_date" value="<?php echo $row['monitoring_start_date']; ?>" required>
                    <label for="monitoring_end_date">Monitoring End Date:</label>
                    <input type="date" id="monitoring_end_date" name="monitoring_end_date" value="<?php echo $row['monitoring_end_date']; ?>" required>
                    <label for="notes">Notes:</label>
                    <textarea id="notes" name="notes"><?php echo $row['notes']; ?></textarea>
                    <input type="submit" name="update" value="Update Monitoring">
                </form>
        <?php
            } else {
                echo "Record not found.";
            }
        } else {
            echo "Monitoring ID not provided.";
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
