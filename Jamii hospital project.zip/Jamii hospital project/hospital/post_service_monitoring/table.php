
<!-- navbar links separate -->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home Page</title>
<style>
    /* Reset default margin and padding */
    body, h1, p {
        margin: 0;
        padding: 0;
    }

    .custom-navbar {
        background-color: #333;
        border-radius: 10px;
        margin-bottom: 20px;
        overflow: hidden;
    }

    .custom-navbar a {
        float: left;
        display: block;
        color: white;
        text-align: center;
        padding: 10px 15px;
        text-decoration: none;
        transition: background-color 0.3s ease;
    }

    .custom-navbar a:hover {
        background-color: #555;
    }
</style>
</head>
<body>
<div class="container">
    <div class="custom-navbar">
        <?php
        // Array of page names and their corresponding URLs
        $pages = array(
            "Home" => "../layout/admin_dashboard.php",
            "Patients" => "../patients/table.php",
            "Staffs" => "../staff_members/table.php",
            "Departments" => "../department/table.php",
            "Medical History" => "../medical_history/table.php",
            "Membership" => "../patient membership/table.php",
            "Wards" => "../ward/table.php",
            "Beds" => "../beds/table.php",
            "Medications" => "../medications/table.php",
            "Prescriptions" => "../prescriptions/table.php",
            "Billing" => "../billings/table.php",
            "Payments" => "../payment/table.php",
            "Appointments" => "../Appointments/table.php",
            "Emergency Patients" => "../emergency_patients/table.php",
            "Emergencies" => "../Emergencies/table.php",
            "Consultations" => "../consultations/table.php",
            "Post Monitoring" => "../post_service_monitoring/table.php"
        );

        // Iterate through the pages array to generate navlinks
        foreach ($pages as $pageTitle => $pageURL) {
            echo "<a href='$pageURL'>$pageTitle</a>";
        }
        ?>
    </div>
</div>
</body>
</html>

<?php


// Database connection details
$servername = "localhost";
$username = "root";
$password = "norah#@$&";
$database = "Jamii1_hospital";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to retrieve post-service monitoring details
$sql = "SELECT m.monitoring_id, p.patient_name, c.consultation_id, m.monitoring_start_date, m.monitoring_end_date, m.notes
        FROM Post_Service_Monitoring m
        JOIN Patients p ON m.patient_id = p.patient_id
        JOIN Consultations c ON m.consultation_id = c.consultation_id";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Post-Service Monitoring</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            color: #333;
        }

        tr:hover {
            background-color: #f0f0f0;
        }

        th {
            background-color: #f2f2f2;
        }

        .action-links button {
            margin-right: 8px;
            padding: 6px 12px;
            background-color: #007bff;
            border: none;
            border-radius: 4px;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .action-links button:hover {
            background-color: #0056b3;
        }

        .no-records {
            text-align: center;
            color: #555;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Post-Service Monitoring</h2>
        <div class="action-links">
            <button onclick="window.location.href='form.php'">Add Monitoring details</button>
        </div>
        <?php if ($result->num_rows > 0) { ?>
            <table>
                <tr>
                    <th>Monitoring ID</th>
                    <th>Patient</th>
                    <th>Consultation</th>
                    <th>Monitoring Start Date</th>
                    <th>Monitoring End Date</th>
                    <th>Notes</th>
                    <th>Action</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row["monitoring_id"]; ?></td>
                        <td><?php echo $row["patient_name"]; ?></td>
                        <td><?php echo $row["consultation_id"]; ?></td>
                        <td><?php echo $row["monitoring_start_date"]; ?></td>
                        <td><?php echo $row["monitoring_end_date"]; ?></td>
                        <td><?php echo $row["notes"]; ?></td>
                        <td>
                            <button onclick="window.location.href='update.php?monitoring_id=<?php echo $row["monitoring_id"]; ?>'">Update</button>
                            <button onclick="if(confirm('Are you sure you want to delete this record?')){window.location.href='delete.php?monitoring_id=<?php echo $row["monitoring_id"]; ?>'}">Delete</button>
                        </td>
                    </tr>
                <?php } ?>
            </table>
        <?php } else { ?>
            <p class="no-records">No records found</p>
        <?php } ?>
    </div>
</body>
</html>

<?php
$conn->close();
?>
