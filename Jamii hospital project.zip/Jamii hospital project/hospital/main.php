<div>
    <nav>
        <?php include 'layout/navbar.php'?>
    </nav>
    
</div>
